#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <omp.h>
#include <time.h>
#include <sys/time.h>

void find_num_primes (void);
void err_sys (const char* message);
int result;
long long int num;
int main (int argc, char* argv[])
{
  if (argc < 2)
    err_sys ("missing command line argument");
  num = strtoll (argv[1], 0 , 10);
  if (num < 0)
    err_sys ("invalid command line argument");

int thread_count = strtol(argv[2], NULL, 10);
long long int i;
result = 0;

time_t start, stop; time(&start);
#pragma omp parallel for  num_threads(thread_count)\
reduction(+:result) schedule(dynamic)
  for (i = 2; i <= num; i++){
    if (is_prime (i))
      result++;}

  time(&stop);
  printf ("%lld primes <= %lld\n", result, num);
  printf("finished in about = %g seconds\n", difftime(stop, start));
  return 0;
}

int is_prime (long long int n)
{
  long long int max = (long long int)sqrt (n);
  long long int i = 2;
  while (i <= max && n % i != 0)
    i++;
  return i > max;
}

void err_sys (const char* message)
{
  printf ("%s\n", message);
  exit (1);
}

