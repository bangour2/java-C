#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <mpi.h>
#include <time.h>
#include <sys/time.h>

long long int find_num_primes (long long int n);
void err_sys (const char* message);

long long int num;
int my_rank;
long long int local_n;
int comm_sz;    /* Number of processes    */
long long int result;

int main (int argc, char* argv[])
{
  //if (argc < 2)
   // err_sys ("missing command line argument");
   num = strtoll (argv[1], 0 , 10);
  if (num < 0)
    err_sys ("invalid command line argument");

   result =0;  
   time_t start, stop; time(&start);

   /* Start up MPI */
   MPI_Init(&argc, &argv); 
   /* Get the number of processes */
   MPI_Comm_size(MPI_COMM_WORLD, &comm_sz); 
   /* Get my rank among all the processes */
   MPI_Comm_rank(MPI_COMM_WORLD, &my_rank); 

    MPI_Bcast(&num, 1, MPI_LONG_LONG_INT, 0, MPI_COMM_WORLD);
   // printf("processs %d \n", my_rank);
    
    long long int num_primes = find_num_primes (num);
    
    time(&stop);  MPI_Barrier(MPI_COMM_WORLD);
 
    if(my_rank ==0){ printf ("%lld primes <= %lld\n", num_primes, num);
    printf("finished in about = %g seconds\n", difftime(stop, start));}

  /* Shut down MPI */
   MPI_Finalize(); 
   return 0;
}

int is_prime (long long int n)
{
  long long int max = (long long int)sqrt (n);
  long long int i = 2;
  while (i <= max && n % i != 0)
    i++;
  return i > max;
}

long long int find_num_primes (long long int n)
{
  local_n = num/comm_sz;
  long long int local_first = (my_rank*local_n)+2;
  long long int local_last = ((my_rank+1)*local_n)+1;
  long long int local_result = 0;

  if(my_rank ==  comm_sz-1) local_last = num;      
  long long int i;
  
 // printf("%d process, %lld first, %lld last \n", my_rank, local_first, local_last);

  for (i = local_first; i <= local_last; i++){
    if (is_prime (i))
    local_result++;}

  MPI_Reduce(&local_result, &result, 1, MPI_LONG_LONG_INT, MPI_SUM, 0, MPI_COMM_WORLD);
  return result;
}

void err_sys (const char* message)
{
  printf ("%s\n", message);
  exit (1);
}
