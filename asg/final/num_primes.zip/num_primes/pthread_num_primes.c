#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <pthread.h>
#include <time.h>
#include <sys/time.h>

void* find_num_primes (void *arg);
void err_sys (const char* message);

int thread_count;

pthread_mutex_t mutex;

long long int result;
long long int num;

int main (int argc, char* argv[])
{
  if (argc < 3)
    err_sys ("missing command line argument");
  num = strtoll (argv[1], 0 , 10);
  if (num < 0)
    err_sys ("invalid command line argument");

   long thread;
   result = 0;

   time_t start, stop; time(&start);
   
   pthread_t* thread_handles; 
   thread_count = strtol(argv[2], NULL, 10);  
   thread_handles = malloc (thread_count*sizeof(pthread_t)); 

    //Initialize the mutex
    if(pthread_mutex_init(&mutex, NULL))
      {printf("Unable to initialize a mutex\n");
       return -1;}


for (thread = 0; thread < thread_count; thread++) 
     pthread_create(&thread_handles[thread], NULL,
          find_num_primes, (void*) thread); 

for (thread = 0; thread < thread_count; thread++)
      pthread_join(thread_handles[thread], NULL);
     

  //Clean up the mutex
  pthread_mutex_destroy(&mutex);
  free(thread_handles);
time(&stop);
printf ("%lld primes <= %lld\n", result, num);
printf("finished in about = %g seconds\n", difftime(stop, start));
return 0;
}

int is_prime (long long int n)
{
  long long int max = (long long int)sqrt (n);
  long long int i = 2;
  while (i <= max && n % i != 0)
    i++;
  return i > max;
}

void* find_num_primes (void* arg)
{
  long thread = (long) arg;
  long long int local_n = num/thread_count;

  long long int local_first = (thread*local_n)+2;
  long long int local_last = ((thread+1)*local_n)+1;

  if(thread ==  thread_count-1) local_last = num;
  long long int i; 
 
 // printf("%d thread, %lld first, %lld last \n", thread, local_first, local_last);

  for (i = local_first; i <= local_last; i++)
  {   
  pthread_mutex_lock(&mutex);
  if (is_prime (i)){result++;}
  pthread_mutex_unlock(&mutex);
}

}

void err_sys (const char* message)
{
  printf ("%s\n", message);
  exit (1);
}

