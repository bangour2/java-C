#include <stdio.h>
#include <string.h>
#include <omp.h>
#define val 20

double mat[val][val];
double A[val][val];
double x[val];

void PrintMatrix(double mat[val][val], int m, int n) {
    int j, i;
for ( j=0;j<n;j++) {
for ( i=0;i<m;i++) {
printf("%+5.2f ",mat[j][i]);
}
printf("\n");
}
}

void FinalPrint(double x[val], int n)
{
 int j;
for ( j=0;j<n;j++) {
printf("%+5.2f \n",x[j]);   
}}
 
int main(int argc, char*argv[]) {
    
if(argc < 4) {printf("please follows command \n");}  
printf("command as follows: row, column, threads \n");    

int n = strtol(argv[1], NULL, 10); 
int m = strtol(argv[2], NULL, 10); 
int thread_count = strtol(argv[3], NULL, 10); 


int i, p, r, c, j;
float multiple;
 

printf("\nEnter all coeficients of the equations :\n\n") ;
for(i = 0 ; i < n ; i++)
{
for(j = 0 ; j < m ; j++)
{
printf("a[%d][%d] = ", i + 1, j + 1) ;
scanf("%lf", &mat[i][j]) ;
}}

printf("Initial matrix\n");
PrintMatrix(mat,m,n);

#pragma omp parallel num_threads(thread_count) 
  {
      #pragma omp master
      {
          thread_count = omp_get_num_threads();
      }

printf("Gaussian elimination\n");
#pragma omp for schedule(static, 1) 
for ( p=0;p<n-1;p++) { 
for ( r=p+1; r < n; r++) { 
multiple = mat[r][p] / mat[p][p]; 
for ( c = 0; c<m; c++) { 
mat[r][c] = mat[r][c] - mat[p][c]*multiple; 
}}}}
PrintMatrix(mat,m,n);


#pragma omp parallel num_threads(thread_count) 
  {
      #pragma omp master
      {
          thread_count = omp_get_num_threads();
      }
 
printf("Upper triangulization\n");
#pragma omp for schedule(static, 1) 
for ( p=0;p<n;p++) { 
for ( c=p+1;c<m;c++) { 
mat[p][c] /= mat[p][p];}
mat[p][p] = 1;}}

PrintMatrix(mat,m,n);
 
printf("Back-substitution\n");


memcpy(&A, &mat, sizeof A);
int row = n;
int col = m;

#pragma omp parallel num_threads(thread_count) 
  {
      #pragma omp master
      {
          thread_count = omp_get_num_threads();
      }
 for (row = n-1; row >= 0; row--) {   
   x[row] = A[row][col-1];
   
   #pragma omp for schedule(static, 1) 
   for (col = row+1; col < n; col++) 
      x[row] -= (A[row][col] * x[col]);
   x[row] /= A[row][row];}}

FinalPrint(x, n);
return 0;
}
